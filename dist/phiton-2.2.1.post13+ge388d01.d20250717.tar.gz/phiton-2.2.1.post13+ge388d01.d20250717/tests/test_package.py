"""Test suite for phiton."""

import phiton


def test_version():
    """Verify package exposes version."""
    assert phiton.__version__
